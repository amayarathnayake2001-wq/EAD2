package com.example.appointment_booking_system.model;

public enum Role {
    USER,
    ADMIN
}

